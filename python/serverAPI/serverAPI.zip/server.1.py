#coding:utf-8
import sys
from flask import Flask,make_response,jsonify,request

from app.index import console

app = Flask(__name__)
# 允许跨域
from flask_cors import CORS
CORS(app, supports_credentials=True)




from functools import wraps

@app.route('/test0')
def test0():
    '''不传 methods，默认是GET请求'''
    return 'test0 success'

@app.route('/test1',methods=['GET'])
def test1():
    '''传 methods 方式为GET，只能获取数据'''
    lon = request.values.get('lon')
    lat = request.values.get('lon')
    result = console(lon=lon,lat=lat,msg='test1 success')
    return jsonify(result)  # 字典转 json

@app.route('/test2',methods=['GET','POST'])
def test2():
    '''
    传 methods 方式为GET或POST,两种方式
    GET 只能获取数据
    POST 能提交数据    
    '''
    lon = request.values.get('lon')
    lat = request.values.get('lon')
    result = console(lon=lon,lat=lat,msg='test2 success')
    return jsonify(result)  # 返回的是字符串

def main(debug):
    port = 8080
    if debug == True:
        app.run(debug=debug,host='0.0.0.0',port=port)
    else:
        from tornado.wsgi import WSGIContainer
        from tornado.httpserver import HTTPServer
        from tornado.ioloop import IOLoop
        import tornado.web
        http_server = HTTPServer(WSGIContainer(app))
        http_server.listen(port)
        IOLoop.instance().start()

if __name__ == "__main__":
    main(debug=True)
    
    
    