#coding:utf-8

def console(*arg,**kwargs):
    result = {}
    for k in kwargs:
        result[k] = kwargs[k]
    return result